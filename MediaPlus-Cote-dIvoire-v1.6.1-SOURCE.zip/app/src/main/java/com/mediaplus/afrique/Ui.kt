package com.mediaplus.afrique

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun Pill(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(50)
    val bg by animateColorAsState(
        targetValue = if (selected) c.primary else if (focused) c.surfaceVariant.copy(alpha = 0.95f) else c.surface,
        label = "tab-background"
    )
    Box(
        modifier.clip(shape).background(bg)
            .border(if (focused) 2.dp else 1.dp, if (focused) c.secondary else if (selected) c.primary else c.outline, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable { onClick() }.padding(vertical = 11.dp, horizontal = 18.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (selected) c.onPrimary else c.onSurface, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
}

@Composable
fun Header(showAccount: Boolean, onAccount: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp))
            .background(Brush.linearGradient(listOf(c.primary, Color(0xFFFF8A00)))),
            contentAlignment = Alignment.Center) {
            Text("M+", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
        }
        Spacer(Modifier.width(10.dp))
        Text("Media+ Côte d’Ivoire", Modifier.weight(1f), color = c.onSurface,
            style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold,
            maxLines = 1)
        if (showAccount) TextButton(onClick = onAccount) {
            Text("Compte", color = c.secondary, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Tile(onClick: () -> Unit, content: @Composable RowScope.() -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(18.dp)
    val bg by animateColorAsState(if (focused) Color(0xFFE8F3EA) else Color.White, label = "tile-background")
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(shape)
            .background(bg)
            .border(if (focused) 2.dp else 1.dp, if (focused) c.primary else c.outline, shape)
            .onFocusChanged { focused = it.isFocused }
            .clickable { onClick() }.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
fun Logo(item: Item) {
    val ctx = LocalContext.current
    var ok by remember(item.logo) { mutableStateOf(false) }
    Box(Modifier.size(58.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFFF0F7F0))) {
        if (!ok) Box(
            Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF08723A), Color(0xFFFF8A00)))),
            contentAlignment = Alignment.Center
        ) { Text(bouquetIcon(item.group), fontSize = 24.sp) }
        if (item.logo.startsWith("http")) {
            AsyncImage(
                model = remember(item.logo) { ImageRequest.Builder(ctx).data(item.logo).size(128).crossfade(true).build() },
                contentDescription = null, contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(4.dp),
                onSuccess = { ok = true }
            )
        }
    }
}

@Composable
fun GroupRow(name: String, count: Int, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Tile(onClick) {
        Box(
            Modifier.size(54.dp).clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(c.secondary, c.primary))),
            contentAlignment = Alignment.Center
        ) { Text(bouquetIcon(name), fontSize = 26.sp) }
        Spacer(Modifier.width(14.dp))
        Text(name, Modifier.weight(1f), color = c.onSurface, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
            maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text("$count", color = c.onSurface, style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.clip(RoundedCornerShape(50)).background(c.surfaceVariant).padding(horizontal = 11.dp, vertical = 5.dp))
        Text("›", color = c.primary, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(start = 10.dp))
    }
}

@Composable
fun ItemRow(item: Item, fav: Boolean, onFav: () -> Unit, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Tile(onClick) {
        Logo(item)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(item.name, color = c.onSurface, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (item.group.isNotEmpty()) Text(item.group, style = MaterialTheme.typography.bodySmall,
                color = c.onSurfaceVariant, maxLines = 1)
        }
        Text(if (fav) "♥" else "♡", color = if (fav) c.tertiary else c.onSurfaceVariant, fontSize = 25.sp,
            modifier = Modifier.clickable { onFav() }.padding(8.dp))
    }
}

@Composable
fun ItemList(
    list: List<Item>, group: String?, query: String, favUrls: Set<String>, flat: Boolean,
    onGroup: (String) -> Unit, onPick: (Item) -> Unit, onFav: (Item) -> Unit, modifier: Modifier = Modifier
) {
    val groups = remember(list) { list.groupBy { it.bouquet() } }
    val found = remember(list, query, flat) {
        if (query.isNotBlank()) list.filter { it.name.contains(query, true) } else if (flat) list else emptyList()
    }
    LazyColumn(modifier) {
        if (flat || query.isNotBlank()) {
            itemsIndexed(found, key = { i, x -> "$i${x.url}" }) { _, x -> ItemRow(x, x.url in favUrls, { onFav(x) }) { onPick(x) } }
        } else if (group == null) {
            val gl = groups.entries.toList()
            itemsIndexed(gl, key = { _, e -> e.key }) { _, e -> GroupRow(e.key, e.value.size) { onGroup(e.key) } }
        } else {
            val l = groups[group] ?: emptyList()
            itemsIndexed(l, key = { i, x -> "$i${x.url}" }) { _, x -> ItemRow(x, x.url in favUrls, { onFav(x) }) { onPick(x) } }
        }
    }
}

@Composable
fun CinemaFeature(item: Item, onPlay: (Item) -> Unit) {
    val c = MaterialTheme.colorScheme
    Box(
        Modifier.fillMaxWidth().height(190.dp).padding(vertical = 8.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF102D58), Color(0xFF07101F))))
            .clickable { onPlay(item) }
    ) {
        if (item.logo.startsWith("http")) {
            AsyncImage(
                model = item.logo,
                contentDescription = item.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xEE07101F), Color(0xBB07101F), Color(0x2207101F)))))
        Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
            Text("À LA UNE", color = c.secondary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(item.name, color = Color.White, style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(12.dp))
            Button(onClick = { onPlay(item) }, shape = RoundedCornerShape(12.dp)) { Text("▶  Regarder") }
        }
    }
}

@Composable
fun CinemaSuggestions(items: List<Item>, onPlay: (Item) -> Unit) {
    if (items.isEmpty()) return
    val c = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text("À découvrir", color = c.onSurface, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items.forEach { item ->
                Column(Modifier.width(126.dp).clip(RoundedCornerShape(14.dp))
                    .background(c.surfaceVariant.copy(alpha = 0.45f)).clickable { onPlay(item) }) {
                    Box(Modifier.fillMaxWidth().height(148.dp).background(Color(0xFF183458))) {
                        if (item.logo.startsWith("http")) {
                            AsyncImage(model = item.logo, contentDescription = item.name,
                                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        } else {
                            Text("▶", color = c.primary, modifier = Modifier.align(Alignment.Center), fontSize = 32.sp)
                        }
                    }
                    Text(item.name, Modifier.padding(8.dp), color = Color.White, maxLines = 2,
                        overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
fun EpgGrid(items: List<Item>, load: suspend (String) -> List<Prog>, onPlay: (Item) -> Unit) {
    val c = MaterialTheme.colorScheme
    val hs = rememberScrollState()
    val progs = remember { mutableStateMapOf<String, List<Prog>>() }
    val t0 = remember { (System.currentTimeMillis() / 1800000L) * 1800000L - 1800000L }
    val now = remember { System.currentTimeMillis() }
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val perMin = 5f
    val slots = 12
    Column(Modifier.fillMaxSize()) {
        Row {
            Spacer(Modifier.width(100.dp))
            Row(Modifier.weight(1f).horizontalScroll(hs)) {
                repeat(slots) { i ->
                    Text(fmt.format(Date(t0 + i * 1800000L)), Modifier.width((30 * perMin).dp), color = c.primary, fontSize = 12.sp)
                }
            }
        }
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(items, key = { i, x -> "$i${x.id}" }) { _, ch ->
                LaunchedEffect(ch.id) {
                    if (progs[ch.id] == null) progs[ch.id] = try { load(ch.id) } catch (e: Exception) { emptyList() }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(ch.name, Modifier.width(100.dp).clickable { onPlay(ch) }.padding(end = 6.dp), fontSize = 12.sp,
                        fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Row(Modifier.weight(1f).horizontalScroll(hs)) {
                        val list = progs[ch.id]
                        if (list == null) Text("…", color = c.onSurfaceVariant)
                        else if (list.isEmpty()) Text("Pas de guide", color = c.onSurfaceVariant, fontSize = 12.sp)
                        else {
                            var cursor = t0
                            list.forEach { p ->
                                val s = maxOf(p.start, t0)
                                val en = minOf(p.end, t0 + slots * 1800000L)
                                if (en > s && s >= cursor) {
                                    if (s > cursor) Spacer(Modifier.width(((s - cursor) / 60000f * perMin).dp))
                                    Box(
                                        Modifier.width(((en - s) / 60000f * perMin).dp).height(52.dp).padding(horizontal = 1.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (now >= p.start && now < p.end) c.primaryContainer else c.surfaceVariant)
                                            .clickable { onPlay(ch) }.padding(6.dp)
                                    ) {
                                        Column {
                                            Text(p.title, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                            Text(fmt.format(Date(p.start)), fontSize = 10.sp, color = c.onSurfaceVariant)
                                        }
                                    }
                                    cursor = en
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
