Media+ Côte d’Ivoire 1.6.1 — source Android

Fond global blanc très discret, touches vert et orange. Confirmation de sortie via bouton Quitter et touche Retour à l’accueil. Depuis les sous-écrans, Retour conserve la navigation existante.

Base : version 1.6.0. Connexions Xtream/MAC, lecture IPTV et sections Direct/Films/Séries préservées dans le code. Les éléments football et le rendu complet de la maquette restent à développer. Non compilé et non testé sur appareil.
