Media+ Côte d’Ivoire v1.8.0 — Aperçu TV en direct. Premier clic sur une chaîne : aperçu vidéo dans le catalogue. Second clic sur la même chaîne ou bouton Agrandir : plein écran. Choisir une autre chaîne remplace l’aperçu. Retour/Fermer ferme l’aperçu. Source uniquement, compilation nécessaire.

Version 2.0.0: apercu video integre dans Direct, disposition cote a cote Android TV, disposition verticale smartphone, second clic pour plein ecran.
