@file:OptIn(UnstableApi::class)

package com.mediaplus.afrique

import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import java.io.File

fun bouquetIcon(name: String): String {
    val n = name.lowercase()
    return when {
        "récemment" in n || "recent" in n -> "🕘"
        "côte d’ivoire" in n || "cote d'ivoire" in n || "ivoire" in n || n.startsWith("ci ") -> "🇨🇮"
        n.startsWith("fr") || "france" in n -> "🇫🇷"
        n.startsWith("uk") || "united kingdom" in n || "royaume-uni" in n -> "🇬🇧"
        n.startsWith("us") || "usa" in n || "états-unis" in n -> "🇺🇸"
        n.startsWith("tn") || "tunisie" in n -> "🇹🇳"
        n.startsWith("ma") || "maroc" in n -> "🇲🇦"
        n.startsWith("dz") || "algérie" in n || "algerie" in n -> "🇩🇿"
        n.startsWith("sn") || "sénégal" in n || "senegal" in n -> "🇸🇳"
        n.startsWith("cm") || "cameroun" in n -> "🇨🇲"
        n.startsWith("be") || "belgique" in n -> "🇧🇪"
        n.startsWith("ch") || "suisse" in n -> "🇨🇭"

        "sport" in n || "foot" in n || "bein" in n -> "⚽"
        "news" in n || "info" in n || "actu" in n -> "📰"
        "film" in n || "movie" in n || "cinema" in n || "cinéma" in n -> "🎬"
        "serie" in n || "série" in n || "novela" in n -> "🍿"
        "kid" in n || "enfant" in n || "cartoon" in n || "jeunesse" in n -> "🧸"
        "music" in n || "musique" in n || "clip" in n -> "🎵"
        "islam" in n || "quran" in n || "coran" in n || "relig" in n -> "🕌"
        "afri" in n -> "🌍"
        "doc" in n || "nature" in n -> "🌿"
        "fr" == n.take(2) -> "🇫🇷"
        else -> "📡"
    }
}

object PlayerCache {
    private var cache: SimpleCache? = null

    @Synchronized
    fun get(ctx: Context): SimpleCache = cache ?: SimpleCache(
        File(ctx.cacheDir, "media"),
        LeastRecentlyUsedCacheEvictor(256L * 1024 * 1024),
        StandaloneDatabaseProvider(ctx)
    ).also { cache = it }

    fun factory(ctx: Context): CacheDataSource.Factory {
        val http = DefaultHttpDataSource.Factory().setUserAgent("MediaPlus/1.0").setAllowCrossProtocolRedirects(true)
        return CacheDataSource.Factory().setCache(get(ctx)).setUpstreamDataSourceFactory(http)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
    }

    fun sizeMb(ctx: Context): Long = get(ctx).cacheSpace / (1024 * 1024)

    fun clear(ctx: Context) {
        val c = get(ctx)
        for (k in c.keys.toList()) c.removeResource(k)
    }
}
