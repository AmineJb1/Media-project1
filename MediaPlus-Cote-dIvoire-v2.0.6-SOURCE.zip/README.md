Media+ Côte d’Ivoire 2.0.2 — source Android

- Aperçu vidéo compact (72 % de largeur sur smartphone), visible uniquement après sélection d’une chaîne.
- Appui sur l’aperçu ou deuxième sélection de la même chaîne : plein écran.
- En plein écran, appui sur la vidéo ou OK : menu limité aux chaînes du bouquet de la chaîne en cours.
- Haut/bas changent de chaîne au sein du même bouquet.
- Signature permanente : conserver les secrets GitHub existants.

Projet source uniquement : APK non compilé ni testé ici.

## Version 2.0.3
Mini-lecteur horizontal compact sur smartphone (44 % largeur), sans grande carte ni texte de plein écran. Appui sur la miniature pour ouvrir le plein écran.

Version 2.0.4: EPG dans le mini-lecteur (Xtream si disponible), résolution réelle, recherche en haut, drapeaux par pays, bouquet des 10 dernières chaînes. Bouquet Côte d’Ivoire : noms à fournir.


## v2.0.5 — Bouquet Côte d’Ivoire
Ajout du bouquet virtuel 🇨🇮 Côte d’Ivoire, visible seulement lorsque le serveur fournit au moins une des 14 chaînes communiquées. Correspondance par nom exact (casse ignorée et espaces externes supprimés). Les chaînes restent aussi dans leurs bouquets d’origine. Aucun flux ni EPG n’est inventé.
