package com.mediaplus.afrique

import android.content.Context
import androidx.compose.runtime.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

fun randomMac(): String = "00:1A:79:" + List(3) { "%02X".format((0..255).random()) }.joinToString(":")

private fun encode(i: Item) = listOf(i.kind, i.id, i.name, i.group, i.url, i.logo).joinToString("\t")

private fun decode(l: String): Item? {
    val p = l.split("\t")
    return if (p.size == 6 && p[0].toIntOrNull() != null) Item(p[0].toInt(), p[1], p[2], p[3], p[4], p[5]) else null
}

class AppState(private val ctx: Context, private val scope: CoroutineScope) {
    private val prefs = ctx.getSharedPreferences("p", 0)
    private val cacheFile = File(ctx.cacheDir, "live.tsv")
    private var stalker: Stalker? = null

    var mode by mutableStateOf(prefs.getInt("mode", 0)) // 0 = identifiants, 1 = MAC
    var user by mutableStateOf(prefs.getString("user", "") ?: "")
    var pass by mutableStateOf(prefs.getString("pass", "") ?: "")
    var mac by mutableStateOf(prefs.getString("mac", null) ?: randomMac().also { prefs.edit().putString("mac", it).apply() })
    var live by mutableStateOf(emptyList<Item>())
    var movies by mutableStateOf<List<Item>?>(null)
    var series by mutableStateOf<List<Item>?>(null)
    var episodes by mutableStateOf<List<Item>?>(null)
    var movieCategories by mutableStateOf(emptyList<String>())
    var seriesCategories by mutableStateOf(emptyList<String>())
    var newestFirst by mutableStateOf(true)
    var section by mutableStateOf(0) // 0 direct, 1 guide, 2 films, 3 séries, 4 favoris
    var group by mutableStateOf<String?>(null)
    var query by mutableStateOf("")
    var status by mutableStateOf("")
    var playing by mutableStateOf<String?>(null)
    var showLogin by mutableStateOf(true)
    var cacheMb by mutableStateOf(0L)
    val favs = mutableStateListOf<Item>()

    init {
        favs.addAll(prefs.getStringSet("favs", emptySet())?.mapNotNull { decode(it) } ?: emptyList())
        if (cacheFile.exists()) {
            live = runCatching { cacheFile.readLines().mapNotNull { decode(it) } }.getOrDefault(emptyList())
            if (live.isNotEmpty()) {
                showLogin = false; status = "${live.size} chaînes"
                if (mode == 1) stalker = Stalker(Config.PORTAL, mac.trim().uppercase())
            }
        }
    }

    private fun xt() = Xtream(Config.SERVER, user, pass)

    private fun fetch(block: suspend () -> Unit) {
        status = "Chargement…"
        scope.launch { try { block(); status = "" } catch (e: Exception) { status = "Erreur : ${e.message}" } }
    }

    fun connect() {
        prefs.edit().putInt("mode", mode).putString("user", user).putString("pass", pass).putString("mac", mac).apply()
        status = "Connexion…"
        scope.launch {
            try {
                val l = withContext(Dispatchers.IO) {
                    val r = if (mode == 0) xt().live() else Stalker(Config.PORTAL, mac.trim().uppercase()).also { stalker = it }.channels()
                    cacheFile.writeText(r.joinToString("\n") { encode(it) })
                    r
                }
                live = l; movies = null; series = null; episodes = null; movieCategories = emptyList(); seriesCategories = emptyList()
                section = 0; group = null; query = ""
                status = "${l.size} chaînes"; showLogin = false
            } catch (e: Exception) { status = "Erreur : ${e.message}" }
        }
    }

    fun current(): List<Item> = episodes ?: when (section) {
        0, 1 -> live
        2 -> movies ?: emptyList()
        3 -> series ?: emptyList()
        else -> favs.toList()
    }

    fun pickSection(s: Int) {
        section = s; group = null; query = ""; episodes = null; status = ""
        if ((s == 2 || s == 3) && mode != 0) { status = "Films et séries : connexion par identifiants requise"; return }
        if (s == 2 && movies == null) refreshCatalog()
        if (s == 3 && series == null) refreshCatalog()
    }

    fun refreshCatalog() {
        if (mode != 0 || (section != 2 && section != 3)) return
        val requested = section
        fetch {
            val catalog = withContext(Dispatchers.IO) {
                if (requested == 2) xt().movieCatalog() else xt().seriesCatalog()
            }
            if (requested == 2) { movies = catalog.items; movieCategories = catalog.categories }
            else { series = catalog.items; seriesCategories = catalog.categories }
        }
    }

    fun pick(i: Item) {
        if (i.kind == 2) {
            fetch { episodes = withContext(Dispatchers.IO) { xt().episodes(i.url) }; group = null; query = "" }
        } else {
            scope.launch {
                try {
                    playing = if (mode == 1 && i.kind == 0) withContext(Dispatchers.IO) { stalker!!.resolve(i.url) } else i.url
                } catch (e: Exception) { status = "Erreur : ${e.message}" }
            }
        }
    }

    fun toggleFav(i: Item) {
        val idx = favs.indexOfFirst { it.url == i.url }
        if (idx >= 0) favs.removeAt(idx) else favs.add(i)
        prefs.edit().putStringSet("favs", favs.map { encode(it) }.toSet()).apply()
    }

    suspend fun epg(id: String): List<Prog> = withContext(Dispatchers.IO) { xt().epg(id) }

    fun onPlayerError(msg: String) {
        val u = playing ?: return
        if (u.endsWith(".m3u8")) playing = u.dropLast(5) + ".ts"
        else { playing = null; status = "Lecture impossible : $msg" }
    }

    fun refreshCache() { cacheMb = PlayerCache.sizeMb(ctx) }
    fun clearCache() { PlayerCache.clear(ctx); refreshCache() }

    fun back() {
        when {
            playing != null -> playing = null
            query.isNotEmpty() -> query = ""
            episodes != null -> { episodes = null; group = null }
            group != null -> group = null
            !showLogin -> showLogin = true
        }
    }
}
