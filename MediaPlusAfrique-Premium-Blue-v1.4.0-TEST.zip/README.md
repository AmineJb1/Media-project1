# Media+ Af — Premium Blue 1.2.0

## Évolution de l'interface
- Identité premium bleu nuit / bleu électrique.
- Bandeau « À la une » avec lecture directe de l'élément mis en avant.
- Rangée horizontale de recommandations à partir des contenus déjà présents dans la bibliothèque IPTV.
- Cartes horizontales navigables et états de focus pour télécommandes Android TV.
- Adaptation aux écrans larges et aux téléphones.

## Fonctions conservées
- Connexion Xtream Codes et MAC/Stalker.
- Direct, EPG, films, séries, favoris.
- Lecteur vidéo Media3 et cache.
- WireGuard volontairement reporté à une version ultérieure.

## Compilation
Workflow GitHub Actions : `.github/workflows/build.yml`.
Java 17, Gradle 8.9, tâche `assembleRelease`.
Cette archive contient le code source. Elle n'est pas un APK compilé. Vérifier la compilation et tester les interactions sur téléphone et Android TV avant distribution.
