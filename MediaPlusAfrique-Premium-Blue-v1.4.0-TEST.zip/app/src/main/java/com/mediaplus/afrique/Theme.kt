package com.mediaplus.afrique

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

val Africa = darkColorScheme(
    primary = Color(0xFF398BFF), onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFF73B7FF), tertiary = Color(0xFFFFC857),
    primaryContainer = Color(0xFF153D70), onPrimaryContainer = Color(0xFFEAF3FF),
    background = Color(0xFF070D18), surface = Color(0xFF101A2B), onSurface = Color(0xFFF5F8FF),
    surfaceVariant = Color(0xFF1B2A42), onSurfaceVariant = Color(0xFFAABBD5),
    outline = Color(0xFF344968)
)

private fun loadBackground(ctx: Context): ImageBitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.assets.open("bg.jpg").use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (o.outWidth / s > 1600) s *= 2
    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
    ctx.assets.open("bg.jpg").use { BitmapFactory.decodeStream(it, null, o2) }?.asImageBitmap()
} catch (e: Exception) { null }

@Composable
fun AfricaTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val bg = remember { loadBackground(ctx) }
    MaterialTheme(colorScheme = Africa) {
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF101F3A), Color(0xFF080F1D), Color(0xFF050914)))
        )) {
            if (bg != null) {
                Image(bg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Color(0xFF050A14).copy(alpha = 0.90f)))
            }
            Surface(Modifier.fillMaxSize(), color = Color.Transparent) { content() }
        }
    }
}

@Composable
fun KenteBand() {
    val cols = listOf(Color(0xFF398BFF), Color(0xFF73B7FF), Color(0xFFFFC857), Color(0xFF14233B))
    Canvas(Modifier.fillMaxWidth().height(5.dp)) {
        val w = size.height
        var x = 0f
        var i = 0
        while (x < size.width) {
            val p = Path().apply { moveTo(x, size.height); lineTo(x + w / 2, 0f); lineTo(x + w, size.height); close() }
            drawPath(p, cols[i % 4])
            x += w; i++
        }
    }
}
