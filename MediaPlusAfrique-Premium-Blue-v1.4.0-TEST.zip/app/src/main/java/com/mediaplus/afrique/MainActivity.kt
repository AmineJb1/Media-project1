package com.mediaplus.afrique

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AfricaTheme { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val s = remember { AppState(ctx.applicationContext, scope) }
    BackHandler(enabled = s.playing != null || !s.showLogin) { s.back() }
    val p = s.playing
    if (p != null) {
        VideoPlayer(p) { s.onPlayerError(it) }
        return
    }
    if (s.showLogin) LoginScreen(s) else MainScreen(s)
}
