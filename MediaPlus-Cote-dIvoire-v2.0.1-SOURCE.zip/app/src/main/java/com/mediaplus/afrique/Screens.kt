package com.mediaplus.afrique

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun LoginScreen(s: AppState) {
    val c = MaterialTheme.colorScheme
    val field = RoundedCornerShape(16.dp)
    val f = Modifier.fillMaxWidth().padding(top = 10.dp)
    LaunchedEffect(Unit) { s.refreshCache() }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 700.dp
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(Color(0xFFE7F5EB), Color.White, Color(0xFFFFF9F1)),
                    radius = 1100f
                )
            )
        )
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = if (wide) 48.dp else 22.dp, vertical = if (wide) 32.dp else 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(if (wide) 68.dp else 58.dp).clip(RoundedCornerShape(20.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF08723A), Color(0xFFFF8A00)))),
                    contentAlignment = Alignment.Center
                ) { Text("M+", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black) }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Media+ Côte d’Ivoire", color = c.onSurface, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text("DIRECT · FILMS · SÉRIES", color = c.secondary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(if (wide) 28.dp else 22.dp))
            Card(
                Modifier.fillMaxWidth().widthIn(max = 560.dp).animateContentSize(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, c.outline),
                elevation = CardDefaults.cardElevation(defaultElevation = 14.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(if (wide) 30.dp else 20.dp)) {
                    Text("Bienvenue", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = c.onSurface)
                    Text("Connectez-vous pour accéder à votre contenu.", color = c.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 5.dp, bottom = 20.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Pill("Identifiants", s.mode == 0, Modifier.weight(1f)) { s.mode = 0 }
                        Pill("Adresse MAC", s.mode == 1, Modifier.weight(1f)) { s.mode = 1 }
                    }
                    if (s.mode == 0) {
                        OutlinedTextField(s.user, { s.user = it }, f, singleLine = true, shape = field, label = { Text("Nom d'utilisateur") })
                        OutlinedTextField(s.pass, { s.pass = it }, f, singleLine = true, shape = field, label = { Text("Mot de passe") }, visualTransformation = PasswordVisualTransformation())
                    } else {
                        OutlinedTextField(s.mac, { s.mac = it }, f, singleLine = true, shape = field, label = { Text("Adresse MAC") })
                    }
                    Button(
                        onClick = { s.connect() },
                        modifier = Modifier.fillMaxWidth().padding(top = 18.dp).height(if (wide) 60.dp else 54.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = c.primary)
                    ) { Text("Se connecter", fontWeight = FontWeight.Bold) }
                    AnimatedVisibility(s.status.isNotEmpty()) {
                        Text(s.status, Modifier.padding(top = 12.dp), color = c.secondary, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("Cache vidéo : ${s.cacheMb} Mo", color = c.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            OutlinedButton({ s.clearCache() }, Modifier.padding(top = 6.dp), shape = RoundedCornerShape(14.dp)) { Text("Vider le cache") }
            Text("Serveur : ${Config.SERVER}", Modifier.padding(top = 16.dp), color = c.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun MainScreen(s: AppState, onExit: () -> Unit = {}) {
    val c = MaterialTheme.colorScheme
    val list = s.current()
    val favUrls = s.favs.map { it.url }.toSet()
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 700.dp
        Column(Modifier.fillMaxSize().padding(horizontal = if (wide) 30.dp else 16.dp)) {
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) { Header(true) { s.showLogin = true; s.status = "" } }
                TextButton(onClick = onExit) { Text("Quitter", color = c.onSurface) }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                when (s.section) { 2 -> "Films"; 3 -> "Séries"; else -> "TV en direct" },
                color = c.onSurface,
                style = if (wide) MaterialTheme.typography.headlineLarge else MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold
            )
            Text("Vos chaînes et vos contenus", color = c.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(5.dp))
            if (s.group != null) {
                TextButton({ s.group = null }) {
                    Text("‹  Retour aux catégories", color = c.secondary, fontWeight = FontWeight.SemiBold)
                }
            }
            if (s.status.isNotEmpty()) {
                Text(s.status, color = c.secondary, style = MaterialTheme.typography.bodySmall)
            }
            if (s.section == 2 || s.section == 3) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { s.refreshCatalog() }) { Text("↻ Actualiser") }
                    TextButton(onClick = { s.newestFirst = !s.newestFirst }) {
                        Text(if (s.newestFirst) "Date ↓" else "Ordre serveur", color = c.onSurface)
                    }
                }
                Text("Tri par date disponible selon les informations du serveur", color = c.onSurfaceVariant,
                    style = MaterialTheme.typography.labelSmall)
            }
            if (s.section == 0 && wide) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Box(Modifier.weight(0.54f).fillMaxHeight()) {
                        ItemList(list, s.group, s.query, favUrls, false,
                            { s.group = it }, { s.pick(it) }, { s.toggleFav(it) }, Modifier.fillMaxSize())
                    }
                    if (s.previewChannelId != null) {
                        Box(Modifier.weight(0.46f).fillMaxHeight()) {
                            LivePreviewPanel(s, compact = false)
                        }
                    }
                }
            } else {
                if (s.section == 0 && s.previewChannelId != null) LivePreviewPanel(s, compact = true)
                ItemList(list, s.group, s.query, favUrls, false,
                    { s.group = it }, { s.pick(it) }, { s.toggleFav(it) }, Modifier.weight(1f),
                    categories = when (s.section) { 2 -> s.movieCategories; 3 -> s.seriesCategories; else -> emptyList() },
                    newestFirst = (s.section == 2 || s.section == 3) && s.newestFirst)
            }
            Spacer(Modifier.height(5.dp))
            OutlinedTextField(
                value = s.query,
                onValueChange = { s.query = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                singleLine = true,
                textStyle = MaterialTheme.typography.bodySmall,
                shape = RoundedCornerShape(24.dp),
                leadingIcon = { Text("⌕", color = c.primary, style = MaterialTheme.typography.titleMedium) },
                trailingIcon = {
                    if (s.query.isNotEmpty()) TextButton(onClick = { s.query = "" }) { Text("×") }
                },
                placeholder = { Text("Rechercher…", style = MaterialTheme.typography.bodySmall) }
            )
            Spacer(Modifier.height(4.dp))
            NavigationBar(
                containerColor = Color.White,
                contentColor = c.onSurface,
                tonalElevation = 0.dp,
                modifier = Modifier.clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
            ) {
                listOf(0 to "Direct", 2 to "Films", 3 to "Séries").forEach { (section, title) ->
                    NavigationBarItem(
                        selected = s.section == section,
                        onClick = { s.pickSection(section) },
                        icon = { Text(when (section) { 0 -> "◉"; 2 -> "▶"; else -> "▣" }, fontSize = androidx.compose.ui.unit.TextUnit.Unspecified) },
                        label = { Text(title, fontWeight = FontWeight.Bold) },
                        alwaysShowLabel = true,
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = c.primary,
                            selectedTextColor = c.primary,
                            unselectedIconColor = Color(0xFF788078),
                            unselectedTextColor = Color(0xFF788078),
                            indicatorColor = Color(0xFFE5F2E8)
                        )
                    )
                }
            }
        }
    }
}


@Composable
private fun LivePreviewPanel(s: AppState, compact: Boolean) {
    val c = MaterialTheme.colorScheme
    val selected = s.live.firstOrNull { it.id == s.previewChannelId }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (selected == null) "Aperçu TV" else s.previewChannelName,
                    Modifier.weight(1f), style = MaterialTheme.typography.titleSmall, color = c.onSurface)
                if (selected != null) TextButton(onClick = { s.clearPreview() }) { Text("Fermer") }
            }
            Box(
                Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(12.dp)).background(Color.Black)
                    .clickable { selected?.let { if (s.previewUrl != null) s.playLive(it) } },
                contentAlignment = Alignment.Center
            ) {
                val url = s.previewUrl
                if (url != null) VideoPlayer(url, onError = { s.onPlayerError(it) },
                    modifier = Modifier.fillMaxSize(), showControls = false)
                else Text(if (selected == null) "Sélectionnez une chaîne pour l’aperçu"
                    else "Chargement de l’aperçu…", color = Color.White)
            }
            if (selected != null) {
                Text("Touchez l’image ou sélectionnez la même chaîne pour agrandir",
                    style = MaterialTheme.typography.labelSmall, color = c.onSurfaceVariant)
                TextButton(onClick = { s.playLive(selected) }, enabled = s.previewUrl != null) {
                    Text("⛶ Plein écran")
                }
            }
        }
    }
}
