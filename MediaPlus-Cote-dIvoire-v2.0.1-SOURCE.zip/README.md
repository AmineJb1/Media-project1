# Media+ Côte d’Ivoire v2.0.1 — Source Android

- Dans Direct, l’aperçu vidéo est masqué tant qu’aucune chaîne n’est sélectionnée.
- Premier appui : aperçu dans Direct ; deuxième appui sur la même chaîne : plein écran.
- Recherche compacte en bas, au-dessus de la navigation Direct / Films / Séries.
- Interface plus resserrée sur smartphone.

Le ZIP contient le code source. Compiler l’APK signé via GitHub Actions avec les secrets de signature déjà configurés.
