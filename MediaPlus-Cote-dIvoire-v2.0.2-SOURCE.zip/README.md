Media+ Côte d’Ivoire 2.0.2 — source Android

- Aperçu vidéo compact (72 % de largeur sur smartphone), visible uniquement après sélection d’une chaîne.
- Appui sur l’aperçu ou deuxième sélection de la même chaîne : plein écran.
- En plein écran, appui sur la vidéo ou OK : menu limité aux chaînes du bouquet de la chaîne en cours.
- Haut/bas changent de chaîne au sein du même bouquet.
- Signature permanente : conserver les secrets GitHub existants.

Projet source uniquement : APK non compilé ni testé ici.
