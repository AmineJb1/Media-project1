package com.mediaplus.afrique

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun LoginScreen(s: AppState) {
    val c = MaterialTheme.colorScheme
    val field = RoundedCornerShape(16.dp)
    val f = Modifier.fillMaxWidth().padding(top = 10.dp)
    LaunchedEffect(Unit) { s.refreshCache() }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 700.dp
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(Color(0xFF173D70).copy(alpha = 0.58f), Color(0xFF091326), Color(0xFF050914)),
                    radius = 1100f
                )
            )
        )
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = if (wide) 48.dp else 22.dp, vertical = if (wide) 32.dp else 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(if (wide) 68.dp else 58.dp).clip(RoundedCornerShape(20.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF65B2FF), Color(0xFF1766D1)))),
                    contentAlignment = Alignment.Center
                ) { Text("M+", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black) }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("MEDIA+ AFRIQUE", color = c.onSurface, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text("VOTRE UNIVERS DE DIVERTISSEMENT", color = c.secondary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(if (wide) 28.dp else 22.dp))
            Card(
                Modifier.fillMaxWidth().widthIn(max = 560.dp).animateContentSize(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xF0111E32)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF29466E)),
                elevation = CardDefaults.cardElevation(defaultElevation = 14.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(if (wide) 30.dp else 20.dp)) {
                    Text("Bienvenue", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = c.onSurface)
                    Text("Connectez-vous pour accéder à votre contenu.", color = c.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 5.dp, bottom = 20.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Pill("Identifiants", s.mode == 0, Modifier.weight(1f)) { s.mode = 0 }
                        Pill("Adresse MAC", s.mode == 1, Modifier.weight(1f)) { s.mode = 1 }
                    }
                    if (s.mode == 0) {
                        OutlinedTextField(s.user, { s.user = it }, f, singleLine = true, shape = field, label = { Text("Nom d'utilisateur") })
                        OutlinedTextField(s.pass, { s.pass = it }, f, singleLine = true, shape = field, label = { Text("Mot de passe") }, visualTransformation = PasswordVisualTransformation())
                    } else {
                        OutlinedTextField(s.mac, { s.mac = it }, f, singleLine = true, shape = field, label = { Text("Adresse MAC") })
                    }
                    Button(
                        onClick = { s.connect() },
                        modifier = Modifier.fillMaxWidth().padding(top = 18.dp).height(if (wide) 60.dp else 54.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = c.primary)
                    ) { Text("Se connecter", fontWeight = FontWeight.Bold) }
                    AnimatedVisibility(s.status.isNotEmpty()) {
                        Text(s.status, Modifier.padding(top = 12.dp), color = c.secondary, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("Cache vidéo : ${s.cacheMb} Mo", color = c.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            OutlinedButton({ s.clearCache() }, Modifier.padding(top = 6.dp), shape = RoundedCornerShape(14.dp)) { Text("Vider le cache") }
            Text("Serveur : ${Config.SERVER}", Modifier.padding(top = 16.dp), color = c.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun MainScreen(s: AppState) {
    val c = MaterialTheme.colorScheme
    val list = s.current()
    val favUrls = s.favs.map { it.url }.toSet()
    val guide = s.section == 1 && s.group != null && s.episodes == null
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 700.dp
        Column(Modifier.fillMaxSize().padding(horizontal = if (wide) 30.dp else 16.dp, vertical = 14.dp)) {
            Header(true) { s.showLogin = true; s.status = "" }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        when (s.section) { 0 -> "En direct"; 1 -> "Guide TV"; 2 -> "Cinéma"; 3 -> "Séries"; else -> "Ma sélection" },
                        style = if (wide) MaterialTheme.typography.headlineLarge else MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold, color = c.onSurface
                    )
                    Text("Découvrez vos programmes", color = c.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
                if (wide) Pill("Mon compte", false) { s.showLogin = true; s.status = "" }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                listOf("Direct", "Guide TV", "Films", "Séries", "Favoris").forEachIndexed { i, t ->
                    Pill(t, s.section == i) { s.pickSection(i) }
                }
            }
            if (s.group != null) {
                TextButton({ s.group = null }) { Text("‹  ${s.group}", color = c.secondary, fontWeight = FontWeight.SemiBold) }
            }
            AnimatedVisibility(s.status.isNotEmpty()) {
                Text(s.status, color = c.secondary, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 6.dp))
            }
            if (guide) {
                if (s.mode != 0) Text("Guide : connexion par identifiants requise", color = c.onSurfaceVariant)
                else Box(Modifier.weight(1f)) { EpgGrid(list.filter { it.bouquet() == s.group }, { s.epg(it) }, { s.pick(it) }) }
            } else {
                OutlinedTextField(
                    s.query, { s.query = it },
                    Modifier.fillMaxWidth(if (wide) 0.72f else 1f).padding(vertical = 12.dp),
                    singleLine = true, shape = RoundedCornerShape(16.dp),
                    label = { Text("Rechercher une chaîne, un film…") }
                )
                ItemList(list, s.group, s.query, favUrls, s.section == 4, { s.group = it }, { s.pick(it) }, { s.toggleFav(it) }, Modifier.weight(1f))
            }
        }
    }
}
